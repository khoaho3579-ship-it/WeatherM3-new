@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.example.weatherm3.ui

import android.Manifest
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.weatherm3.core.L
import com.example.weatherm3.core.LocalL
import com.example.weatherm3.data.AppSettings
import com.example.weatherm3.ui.components.ActionRow
import com.example.weatherm3.ui.components.AdaptiveChoice
import com.example.weatherm3.ui.components.AppOutlinedButton
import com.example.weatherm3.ui.components.AppTonalButton
import com.example.weatherm3.ui.components.Card28
import com.example.weatherm3.ui.components.TonalIcon
import com.example.weatherm3.ui.theme.FONT_KEYS
import com.example.weatherm3.ui.theme.SEED_COLORS
import com.example.weatherm3.ui.theme.dominantColor
import com.example.weatherm3.ui.theme.fontFamilyFor
import com.example.weatherm3.ui.theme.iconShape
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---------- khối dựng chung ----------
@Composable
private fun Group(title: String, icon: ImageVector, content: @Composable ColumnScope.() -> Unit) {
    Card28(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth().heightIn(min = 40.dp), verticalAlignment = Alignment.CenterVertically) {
                TonalIcon(icon)
                Spacer(Modifier.width(12.dp))
                Text(title, Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            content()
        }
    }
}

@Composable
private fun Label(text: String) =
    Text(text, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)

@Composable
private fun SwitchRow(title: String, desc: String?, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            if (desc != null) Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            enabled = enabled,
            thumbContent = if (checked) {
                { Icon(Icons.Rounded.Check, null, Modifier.size(SwitchDefaults.IconSize)) }
            } else null
        )
    }
}

@Composable
private fun Chips(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        options.forEach { (k, label) ->
            FilterChip(selected = selected == k, onClick = { onSelect(k) }, label = { Text(label, maxLines = 2, overflow = TextOverflow.Ellipsis) })
        }
    }
}

@Composable
private fun Segmented(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) =
    AdaptiveChoice(options, selected, onSelect)

// ---------- màn hình ----------
@Composable
fun SettingsScreen(vm: AppViewModel) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val l = LocalL.current
    val scroll = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
    val bg = MaterialTheme.colorScheme.background
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    fun upd(t: (AppSettings) -> AppSettings) = vm.updateSettings(t)

    // quyền thông báo (Android 13+)
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (!ok) vm.notifyMessage("Chưa cấp quyền thông báo", "Notification permission not granted")
    }
    fun askNotif() {
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    val locPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.any { it }) vm.useGps() else vm.notifyMessage("Chưa cấp quyền vị trí", "Location permission not granted")
    }
    // sao lưu / khôi phục
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching { ctx.contentResolver.openOutputStream(uri)?.use { it.write(vm.exportJson().toByteArray()) } }.isSuccess
            }
            vm.notifyMessage(if (ok) "Đã sao lưu cài đặt" else "Sao lưu thất bại", if (ok) "Backup saved" else "Backup failed")
        }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            val text = withContext(Dispatchers.IO) {
                runCatching { ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } }.getOrNull()
            }
            if (text != null) vm.importJson(text) else vm.notifyMessage("Không đọc được file", "Couldn't read file")
        }
    }
    // lấy màu từ ảnh
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) scope.launch {
            val color = withContext(Dispatchers.IO) {
                runCatching {
                    val opts = BitmapFactory.Options().apply { inSampleSize = 4 }
                    val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                    if (bmp == null) null else {
                        val small = Bitmap.createScaledBitmap(bmp, 48, 48, true)
                        val px = IntArray(48 * 48)
                        small.getPixels(px, 0, 48, 0, 0, 48, 48)
                        dominantColor(px)
                    }
                }.getOrNull()
            }
            if (color != null) upd { it.copy(seed = color, dynamicColor = false) }
            else vm.notifyMessage("Không đọc được ảnh", "Couldn't read image")
        }
    }

    Scaffold(
        modifier = Modifier.nestedScroll(scroll.nestedScrollConnection),
        containerColor = bg,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            LargeTopAppBar(
                title = { Text(l.t("Cài đặt", "Settings")) },
                scrollBehavior = scroll,
                colors = TopAppBarDefaults.topAppBarColors(containerColor = bg, scrolledContainerColor = MaterialTheme.colorScheme.surfaceContainer)
            )
        }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 1. Giao diện
            item {
                Group(l.t("Giao diện", "Appearance"), Icons.Rounded.LightMode) {
                    Label(l.t("Chế độ sáng / tối", "Light / dark mode"))
                    Segmented(
                        listOf("system" to l.t("Hệ thống", "System"), "light" to l.t("Sáng", "Light"), "dark" to l.t("Tối", "Dark"), "amoled" to "AMOLED"),
                        s.theme
                    ) { v -> upd { it.copy(theme = v) } }
                }
            }
            // 2. Ngôn ngữ
            item {
                Group(l.t("Ngôn ngữ", "Language"), Icons.Rounded.Language) {
                    Segmented(
                        listOf("system" to l.t("Hệ thống", "System"), "vi" to "Tiếng Việt", "en" to "English"),
                        s.language
                    ) { v -> upd { it.copy(language = v) } }
                    Label(l.t("Áp dụng ngay, không cần khởi động lại.", "Applies instantly, no restart needed."))
                }
            }
            // 3. Màu sắc
            item { ColorGroup(s, l, ::upd) { picker.launch("image/*") } }
            // 4. Phông chữ
            item { FontGroup(s, l, ::upd) }
            // 5. Hình dạng & chuyển động
            item {
                Group(l.t("Hình dạng & chuyển động", "Shape & motion"), Icons.Rounded.Tune) {
                    Label(l.t("Độ bo góc toàn app", "Corner roundness"))
                    Chips(
                        listOf("square" to l.t("Vuông", "Square"), "standard" to l.t("Chuẩn", "Standard"), "round" to l.t("Bo nhiều", "Rounder"), "max" to l.t("Bo tối đa", "Max")),
                        s.corners
                    ) { v -> upd { it.copy(corners = v) } }
                    Label(l.t("Khung icon thời tiết", "Weather icon frame"))
                    Chips(
                        listOf("circle" to l.t("Tròn", "Circle"), "cookie" to "Cookie", "flower" to l.t("Hoa", "Flower"), "sunny" to "Sunny", "squircle" to l.t("Vuông bo", "Squircle")),
                        s.iconShape
                    ) { v -> upd { it.copy(iconShape = v) } }
                    Box(
                        Modifier.size(64.dp).clip(iconShape(s.iconShape)).background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Rounded.WbSunny, null, tint = MaterialTheme.colorScheme.onPrimaryContainer) }
                    Label(l.t("Kiểu chuyển động", "Motion style"))
                    Segmented(
                        listOf("expressive" to l.t("Nảy (Expressive)", "Bouncy"), "standard" to l.t("Mượt", "Smooth"), "off" to l.t("Tắt", "Off")),
                        s.motion
                    ) { v -> upd { it.copy(motion = v) } }
                    SwitchRow(l.t("Rung phản hồi", "Haptic feedback"), null, s.haptics) { v -> upd { it.copy(haptics = v) } }
                    SwitchRow(l.t("Nền động theo thời tiết", "Animated weather background"), l.t("Mưa, tuyết, sao, quầng nắng", "Rain, snow, stars, sun glow"), s.weatherBg) { v -> upd { it.copy(weatherBg = v) } }
                    SwitchRow(l.t("Icon thời tiết chuyển động", "Animated weather icons"), null, s.weatherAnim) { v -> upd { it.copy(weatherAnim = v) } }
                    SwitchRow(l.t("Tiết kiệm pin", "Battery saver"), l.t("Tắt hoạt ảnh thời tiết", "Turns off weather animations"), s.batterySaver) { v -> upd { it.copy(batterySaver = v) } }
                }
            }
            // 6. Đơn vị
            item {
                Group(l.t("Đơn vị", "Units"), Icons.Rounded.Straighten) {
                    Label(l.t("Nhiệt độ", "Temperature"))
                    Chips(listOf("c" to "°C", "f" to "°F"), s.tempUnit) { v -> upd { it.copy(tempUnit = v) } }
                    Label(l.t("Tốc độ gió", "Wind speed"))
                    Chips(listOf("kmh" to "km/h", "ms" to "m/s", "mph" to "mph", "kn" to "kn", "bft" to "Beaufort"), s.windUnit) { v -> upd { it.copy(windUnit = v) } }
                    Label(l.t("Áp suất", "Pressure"))
                    Chips(listOf("hpa" to "hPa", "mmhg" to "mmHg", "inhg" to "inHg"), s.pressureUnit) { v -> upd { it.copy(pressureUnit = v) } }
                    Label(l.t("Lượng mưa", "Precipitation"))
                    Chips(listOf("mm" to "mm", "in" to "in"), s.rainUnit) { v -> upd { it.copy(rainUnit = v) } }
                    Label(l.t("Tầm nhìn", "Visibility"))
                    Chips(listOf("km" to "km", "mi" to "mi"), s.visUnit) { v -> upd { it.copy(visUnit = v) } }
                    Label(l.t("Định dạng giờ", "Time format"))
                    Chips(listOf("24" to "24h", "12" to "12h"), if (s.hour24) "24" else "12") { v -> upd { it.copy(hour24 = v == "24") } }
                }
            }
            // 7. Vị trí
            item {
                Group(l.t("Vị trí", "Location"), Icons.Rounded.MyLocation) {
                    Text(l.t("Địa điểm hiện tại: ", "Current place: ") + s.activePlace().name, style = MaterialTheme.typography.bodyMedium)
                    AppTonalButton(l.t("Dùng vị trí GPS", "Use GPS location"), onClick = {
                        locPerm.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
                    })
                    Label(l.t("Thêm / sắp xếp / xóa địa điểm ở tab Địa điểm.", "Add, reorder or delete places in the Locations tab."))
                }
            }
            // 8. Nguồn dữ liệu
            item { DataGroup(vm, s, l, ::upd) }
            // 9. Thông báo
            item { NotifGroup(s, l, ::upd, ::askNotif) }
            // Thẻ trang chủ
            item { CardsGroup(s, l, ::upd) }
            // Sao lưu
            item {
                Group(l.t("Sao lưu & khôi phục", "Backup & restore"), Icons.Rounded.Backup) {
                    Label(l.t("Xuất/nhập cài đặt ra file JSON (không gồm API key).", "Export/import settings as JSON (API key excluded)."))
                    ActionRow {
                        AppTonalButton(l.t("Sao lưu", "Export"), onClick = { exporter.launch("weatherm3-settings.json") })
                        AppOutlinedButton(l.t("Khôi phục", "Import"), onClick = { importer.launch(arrayOf("application/json", "text/plain", "*/*")) })
                    }
                }
            }
            // Style guide
            item { StyleGuide(l) }
            // Quyền riêng tư
            item {
                Group(l.t("Dữ liệu & quyền riêng tư", "Data & privacy"), Icons.Rounded.Storage) {
                    Text(
                        l.t("Chỉ tọa độ địa điểm được gửi tới nguồn thời tiết bạn chọn. Không có theo dõi hay quảng cáo.",
                            "Only the coordinates of your places are sent to the weather source you choose. No tracking or ads."),
                        style = MaterialTheme.typography.bodySmall
                    )
                    ActionRow {
                        AppOutlinedButton(l.t("Xóa địa điểm đã lưu", "Clear saved places"), onClick = { vm.clearPlaceHistory() })
                        AppOutlinedButton(l.t("Quyền ứng dụng", "App permissions"), onClick = {
                            ctx.startActivity(
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        })
                    }
                }
            }
            // Dành cho nhà phát triển
            item {
                Group(l.t("Dành cho nhà phát triển", "Developer"), Icons.Rounded.Tune) {
                    SwitchRow(l.t("Lớp phủ FPS", "FPS overlay"), l.t("FPS, thời gian frame trung bình/P95, số frame rớt. Kéo để di chuyển.", "FPS, avg/P95 frame time, dropped frames. Drag to move."), s.fpsOverlay) { v -> upd { it.copy(fpsOverlay = v) } }
                    SwitchRow(l.t("Chế độ thử tràn chữ", "Text overflow test mode"), l.t("Ép cỡ chữ ×2.0 để kiểm tra layout.", "Forces ×2.0 text scale to check layouts."), s.overflowTest) { v -> upd { it.copy(overflowTest = v) } }
                }
            }
            // Giới thiệu
            item {
                Group(l.t("Giới thiệu", "About"), Icons.Rounded.Info) {
                    Text("Weather M3 · 3.0.0", style = MaterialTheme.typography.titleMedium)
                    Text(
                        l.t(
                            "Dữ liệu thời tiết & chất lượng không khí: Open-Meteo.com (CC BY 4.0) hoặc Google Maps Platform Weather API. Radar: RainViewer. Bản đồ: © OpenStreetMap, © CARTO. Thư viện mã nguồn mở: AndroidX / Jetpack Compose / Material 3 (Apache-2.0), Retrofit & OkHttp (Apache-2.0), kotlinx.serialization (Apache-2.0), Leaflet (BSD-2), material-color-utilities (Apache-2.0). Không dùng logo/phông chữ độc quyền của Google.",
                            "Weather & air quality data: Open-Meteo.com (CC BY 4.0) or Google Maps Platform Weather API. Radar: RainViewer. Map: © OpenStreetMap, © CARTO. Open-source libraries: AndroidX / Jetpack Compose / Material 3 (Apache-2.0), Retrofit & OkHttp (Apache-2.0), kotlinx.serialization (Apache-2.0), Leaflet (BSD-2), material-color-utilities (Apache-2.0). No proprietary Google logos or fonts are used."
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

// ---------- Màu sắc ----------
@Composable
private fun ColorGroup(s: AppSettings, l: L, upd: ((AppSettings) -> AppSettings) -> Unit, pickImage: () -> Unit) {
    val dynSupported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    val hsv = remember(s.seed) { FloatArray(3).also { android.graphics.Color.colorToHSV(s.seed, it) } }
    var hue by remember(s.seed) { mutableFloatStateOf(hsv[0]) }
    var hex by remember(s.seed) { mutableStateOf("%06X".format(s.seed and 0xFFFFFF)) }

    Group(l.t("Hệ thống màu sắc", "Color system"), Icons.Rounded.Palette) {
        SwitchRow(
            l.t("Màu động (Material You)", "Dynamic color (Material You)"),
            if (dynSupported) l.t("Lấy màu từ hình nền Android 12+", "Uses your Android 12+ wallpaper") else l.t("Cần Android 12 trở lên", "Requires Android 12+"),
            s.dynamicColor && dynSupported, enabled = dynSupported
        ) { v -> upd { it.copy(dynamicColor = v) } }

        Label(l.t("Màu gốc (seed)", "Seed color"))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SEED_COLORS.forEach { c ->
                Box(
                    Modifier.size(48.dp).clip(CircleShape).background(Color(c))
                        .clickable { upd { it.copy(seed = c, dynamicColor = false) } },
                    contentAlignment = Alignment.Center
                ) {
                    if (c == s.seed) Icon(Icons.Rounded.Check, null, tint = Color.White)
                }
            }
        }
        Label(l.t("Sắc độ tùy chỉnh", "Custom hue"))
        Slider(
            value = hue,
            onValueChange = { hue = it },
            onValueChangeFinished = {
                val c = android.graphics.Color.HSVToColor(floatArrayOf(hue, 0.65f, 0.75f))
                upd { it.copy(seed = c, dynamicColor = false) }
            },
            valueRange = 0f..360f
        )
        OutlinedTextField(
            value = hex,
            onValueChange = { v ->
                val clean = v.removePrefix("#").uppercase().filter { it in "0123456789ABCDEF" }.take(6)
                hex = clean
                if (clean.length == 6) {
                    val c = (0xFF000000L or clean.toLong(16)).toInt()
                    upd { it.copy(seed = c, dynamicColor = false) }
                }
            },
            label = { Text("HEX (#RRGGBB)") },
            prefix = { Text("#") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        AppOutlinedButton(l.t("Lấy màu từ ảnh…", "Pick color from image…"), onClick = pickImage)

        Label(l.t("Kiểu bảng màu", "Palette style"))
        Chips(
            listOf(
                "tonal" to "Tonal Spot", "vibrant" to "Vibrant", "expressive" to "Expressive",
                "neutral" to "Neutral", "mono" to "Monochrome", "fidelity" to "Fidelity"
            ),
            s.paletteStyle
        ) { v -> upd { it.copy(paletteStyle = v) } }
        Label(l.t("Mức tương phản", "Contrast"))
        Segmented(
            listOf("0" to l.t("Chuẩn", "Standard"), "1" to l.t("Vừa", "Medium"), "2" to l.t("Cao", "High")),
            s.contrast.toString()
        ) { v -> upd { it.copy(contrast = v.toInt()) } }
        if (s.dynamicColor && dynSupported) {
            Label(l.t("Tắt Màu động để dùng màu gốc / kiểu bảng màu / tương phản.", "Turn off Dynamic color to use seed / style / contrast."))
        }
        Label(l.t("Xem trước vai trò màu", "Color roles preview"))
        val cs = MaterialTheme.colorScheme
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(
                "primary" to cs.primary, "secondary" to cs.secondary, "tertiary" to cs.tertiary,
                "primaryC" to cs.primaryContainer, "secondaryC" to cs.secondaryContainer, "tertiaryC" to cs.tertiaryContainer,
                "surface" to cs.surface, "surfaceC" to cs.surfaceContainerHigh, "error" to cs.error
            ).forEach { (n, c) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(44.dp).clip(CircleShape).background(c))
                    Text(n, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

// ---------- Phông chữ ----------
@Composable
private fun FontGroup(s: AppSettings, l: L, upd: ((AppSettings) -> AppSettings) -> Unit) {
    var scale by remember(s.fontScale) { mutableFloatStateOf(s.fontScale) }
    val names = mapOf(
        "default" to l.t("Mặc định hệ thống", "System default"), "sans" to "Sans", "condensed" to l.t("Hẹp", "Condensed"),
        "serif" to "Serif", "mono" to "Mono", "casual" to "Casual", "cursive" to "Cursive"
    )
    Group(l.t("Phông chữ", "Typography"), Icons.Rounded.TextFields) {
        Label(l.t("Kiểu chữ", "Font"))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            FONT_KEYS.forEach { k ->
                FilterChip(
                    selected = s.font == k,
                    onClick = { upd { it.copy(font = k) } },
                    label = { Text(names[k] ?: k, fontFamily = fontFamilyFor(k)) }
                )
            }
        }
        Label(l.t("Tỷ lệ chữ của app: ", "App text scale: ") + "${(scale * 100).toInt()}%")
        Slider(
            value = scale, onValueChange = { scale = it },
            onValueChangeFinished = { upd { it.copy(fontScale = scale) } },
            valueRange = 0.8f..1.5f
        )
        Label(l.t("Giới hạn tổng độ phóng chữ (hệ thống × app)", "Cap on total text scaling (system × app)"))
        Chips(
            listOf("0" to l.t("Tắt", "Off"), "130" to "130%", "150" to "150%", "200" to "200%"),
            s.fontCap.toString()
        ) { v -> upd { it.copy(fontCap = v.toInt()) } }
        val sysScale = LocalContext.current.resources.configuration.fontScale
        val effScale = LocalDensity.current.fontScale
        Text(
            l.t("Hệ thống ", "System ") + "${(sysScale * 100).toInt()}%" + " × app " + "${(scale * 100).toInt()}%" +
                l.t(" → tổng hiệu dụng ", " → effective ") + "${(effScale * 100).toInt()}%",
            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary
        )
        Label(l.t("Độ đậm", "Weight"))
        Segmented(
            listOf("0" to l.t("Nhẹ", "Light"), "1" to l.t("Chuẩn", "Regular"), "2" to l.t("Đậm", "Bold")),
            s.fontWeight.toString()
        ) { v -> upd { it.copy(fontWeight = v.toInt()) } }
        SwitchRow(l.t("Kiểu chữ nhấn mạnh (Expressive)", "Emphasized type (Expressive)"), null, s.emphasized) { v -> upd { it.copy(emphasized = v) } }
        Text(l.t("Phông hệ thống không có trục độ đậm liên tục nên độ đậm được giới hạn 300–700. Roboto Flex / Be Vietnam Pro chưa được nhúng (cần file phông).", "System fonts have no continuous weight axis, so weight is clamped to 300–700. Roboto Flex / Be Vietnam Pro are not bundled yet (font files required)."),
            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Label(l.t("Xem trước", "Preview"))
        val t = MaterialTheme.typography
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("-12°F", style = t.displayLarge, maxLines = 1, softWrap = false)
            Text("Ầ Ễ Ữ Ậ Ợ · Cảm giác như -12°", style = t.titleLarge)
            Text(l.t("Hôm nay nhiều mây", "Cloudy today"), style = t.headlineMedium)
            Text(l.t("Dự báo 10 ngày tới", "10-day outlook"), style = t.titleLarge)
            Text(l.t("Khả năng mưa rào vào buổi chiều, gió nhẹ.", "Chance of afternoon showers, light wind."), style = t.bodyLarge)
            Text(l.t("Cập nhật lúc 14:30 · Độ ẩm 74%", "Updated 14:30 · Humidity 74%"), style = t.labelMedium)
        }
    }
}

// ---------- Nguồn dữ liệu ----------
@Composable
private fun DataGroup(vm: AppViewModel, s: AppSettings, l: L, upd: ((AppSettings) -> AppSettings) -> Unit) {
    var key by remember { mutableStateOf("") }
    val hasKey = remember(s.googleKeyVersion) { vm.hasGoogleKey() }
    Group(l.t("Nguồn dữ liệu", "Data source"), Icons.Rounded.Cloud) {
        Segmented(listOf("openmeteo" to "Open-Meteo", "google" to "Google Weather"), s.source) { v -> upd { it.copy(source = v) } }
        if (s.source == "google") {
            OutlinedTextField(
                value = key,
                onValueChange = { key = it },
                label = { Text("Google Maps Platform API key") },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            ActionRow {
                AppTonalButton(l.t("Lưu key", "Save key"), onClick = { vm.saveGoogleKey(key); key = "" }, enabled = key.isNotBlank())
                if (hasKey) AppOutlinedButton(l.t("Xóa key", "Remove key"), onClick = { vm.saveGoogleKey("") })
            }
            Label(
                (if (hasKey) l.t("Đã có key (mã hóa trên máy). ", "Key stored (encrypted). ") else l.t("Chưa có key. ", "No key yet. ")) +
                    l.t("Cần bật Weather API và billing/Demo Key; hãy tự kiểm tra giá & điều khoản hiện hành của Google.",
                        "Requires Weather API enabled with billing/Demo Key; check Google's current pricing & terms.")
            )
        }
        Label(l.t("Cập nhật nền mỗi", "Background refresh every"))
        Chips(
            listOf("15" to l.t("15 phút", "15 min"), "30" to l.t("30 phút", "30 min"), "60" to l.t("1 giờ", "1 h"), "180" to l.t("3 giờ", "3 h")),
            s.refreshMinutes.toString()
        ) { v -> upd { it.copy(refreshMinutes = v.toInt()) } }
        SwitchRow(l.t("Chỉ cập nhật khi có Wi-Fi", "Update on Wi-Fi only"), null, s.wifiOnly) { v -> upd { it.copy(wifiOnly = v) } }
        AppOutlinedButton(l.t("Xóa bộ nhớ đệm", "Clear cache"), onClick = { vm.clearCache() })
    }
}

// ---------- Thông báo ----------
@Composable
private fun NotifGroup(s: AppSettings, l: L, upd: ((AppSettings) -> AppSettings) -> Unit, askNotif: () -> Unit) {
    var showTime by remember { mutableStateOf(false) }
    Group(l.t("Thông báo", "Notifications"), Icons.Rounded.Notifications) {
        SwitchRow(l.t("Dự báo hằng ngày", "Daily forecast"), "%02d:%02d".format(s.dailyHour, s.dailyMinute), s.dailyOn) { v ->
            if (v) askNotif()
            upd { it.copy(dailyOn = v) }
        }
        if (s.dailyOn) AppOutlinedButton(l.t("Chọn giờ", "Pick time"), onClick = { showTime = true })
        SwitchRow(l.t("Cảnh báo mưa / dông / nhiệt độ cực đoan", "Rain / storm / extreme temperature alerts"), null, s.alertsOn) { v ->
            if (v) askNotif()
            upd { it.copy(alertsOn = v) }
        }
        SwitchRow(l.t("Thông báo cố định (nhiệt độ hiện tại)", "Ongoing notification (current temperature)"), null, s.ongoingOn) { v ->
            if (v) askNotif()
            upd { it.copy(ongoingOn = v) }
        }
        Label(l.t("Thông báo nền chạy theo chu kỳ cập nhật nên có thể trễ vài phút.", "Background alerts follow the refresh interval and may be delayed."))
    }
    if (showTime) {
        val st = rememberTimePickerState(s.dailyHour, s.dailyMinute, s.hour24)
        AlertDialog(
            onDismissRequest = { showTime = false },
            confirmButton = {
                TextButton(onClick = { upd { it.copy(dailyHour = st.hour, dailyMinute = st.minute) }; showTime = false }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showTime = false }) { Text(l.t("Hủy", "Cancel")) } },
            text = { TimePicker(state = st) }
        )
    }
}

// ---------- Thẻ trang chủ ----------
@Composable
private fun CardsGroup(s: AppSettings, l: L, upd: ((AppSettings) -> AppSettings) -> Unit) {
    val names = mapOf(
        "aqi" to l.t("Chất lượng không khí", "Air quality"), "wind" to l.t("Gió", "Wind"), "humidity" to l.t("Độ ẩm", "Humidity"),
        "pressure" to l.t("Áp suất", "Pressure"), "visibility" to l.t("Tầm nhìn", "Visibility"), "uv" to l.t("Chỉ số UV", "UV index"),
        "sun" to l.t("Mặt trời mọc/lặn", "Sunrise/sunset"), "rain" to l.t("Khả năng mưa", "Rain chance")
    )
    val order = s.orderedCards()
    Group(l.t("Thẻ trang chủ", "Home cards"), Icons.Rounded.Tune) {
        order.forEachIndexed { i, k ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = k !in s.hiddenCards, onCheckedChange = { on ->
                    upd { it.copy(hiddenCards = if (on) it.hiddenCards - k else (it.hiddenCards + k).distinct()) }
                })
                Text(names[k] ?: k, Modifier.weight(1f).padding(start = 12.dp), style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                IconButton(onClick = {
                    if (i > 0) upd { cur -> val m = order.toMutableList(); m.add(i - 1, m.removeAt(i)); cur.copy(cardOrder = m) }
                }) { Icon(Icons.Rounded.ArrowUpward, l.t("Lên", "Up")) }
                IconButton(onClick = {
                    if (i < order.size - 1) upd { cur -> val m = order.toMutableList(); m.add(i + 1, m.removeAt(i)); cur.copy(cardOrder = m) }
                }) { Icon(Icons.Rounded.ArrowDownward, l.t("Xuống", "Down")) }
            }
        }
    }
}

// ---------- Style guide ----------
@Composable
private fun StyleGuide(l: L) {
    var open by remember { mutableStateOf(false) }
    Group(l.t("Style guide (debug)", "Style guide (debug)"), Icons.Rounded.Palette) {
        AppOutlinedButton(if (open) l.t("Ẩn", "Hide") else l.t("Hiện thang màu / chữ / hình dạng", "Show color / type / shape scales"), onClick = { open = !open })
        if (open) {
            val cs = MaterialTheme.colorScheme
            val roles = listOf(
                Triple("primary", cs.primary, cs.onPrimary), Triple("primaryContainer", cs.primaryContainer, cs.onPrimaryContainer),
                Triple("secondary", cs.secondary, cs.onSecondary), Triple("secondaryContainer", cs.secondaryContainer, cs.onSecondaryContainer),
                Triple("tertiary", cs.tertiary, cs.onTertiary), Triple("tertiaryContainer", cs.tertiaryContainer, cs.onTertiaryContainer),
                Triple("error", cs.error, cs.onError), Triple("errorContainer", cs.errorContainer, cs.onErrorContainer),
                Triple("surface", cs.surface, cs.onSurface), Triple("surfaceContainerLow", cs.surfaceContainerLow, cs.onSurface),
                Triple("surfaceContainer", cs.surfaceContainer, cs.onSurface), Triple("surfaceContainerHighest", cs.surfaceContainerHighest, cs.onSurface),
                Triple("inverseSurface", cs.inverseSurface, cs.inverseOnSurface)
            )
            roles.forEach { (n, bgc, fg) ->
                Box(Modifier.fillMaxWidth().clip(MaterialTheme.shapes.small).background(bgc).padding(10.dp)) {
                    Text(n, color = fg, style = MaterialTheme.typography.labelMedium)
                }
            }
            val t = MaterialTheme.typography
            listOf(
                "displayLarge" to t.displayLarge, "displayMedium" to t.displayMedium, "displaySmall" to t.displaySmall,
                "headlineLarge" to t.headlineLarge, "headlineMedium" to t.headlineMedium, "headlineSmall" to t.headlineSmall,
                "titleLarge" to t.titleLarge, "titleMedium" to t.titleMedium, "titleSmall" to t.titleSmall,
                "bodyLarge" to t.bodyLarge, "bodyMedium" to t.bodyMedium, "bodySmall" to t.bodySmall,
                "labelLarge" to t.labelLarge, "labelMedium" to t.labelMedium, "labelSmall" to t.labelSmall
            ).forEach { (n, st) -> Text(n, style = st, maxLines = 1) }
            val sh = MaterialTheme.shapes
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(sh.extraSmall, sh.small, sh.medium, sh.large, sh.extraLarge).forEach {
                    Box(Modifier.size(48.dp).clip(it).background(cs.primaryContainer))
                }
            }
        }
    }
}
