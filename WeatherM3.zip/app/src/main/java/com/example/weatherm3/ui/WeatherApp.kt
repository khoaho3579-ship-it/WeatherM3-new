@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.weatherm3.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.Place
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material.icons.rounded.Place
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.layout.layout
import androidx.compose.ui.text.style.TextOverflow
import com.example.weatherm3.ui.components.isBigFont
import com.example.weatherm3.ui.dev.FpsOverlay
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.weatherm3.core.LocalL
import com.example.weatherm3.ui.theme.LocalMotion

private enum class Tab(val id: Int) { TODAY(0), FORECAST(1), RADAR(2), PLACES(3), SETTINGS(4) }

@Composable
fun WeatherApp(vm: AppViewModel) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val l = LocalL.current
    val motion = LocalMotion.current
    var tabId by rememberSaveable { mutableStateOf(0) }
    val tab = Tab.values().first { it.id == tabId }
    val snack = remember { SnackbarHostState() }
    val msg by vm.message.collectAsStateWithLifecycle()
    val haptic = LocalHapticFeedback.current
    val bigFont = isBigFont()
    val screenW = LocalConfiguration.current.screenWidthDp
    // Chữ rất lớn thì dùng NavigationRail để nhãn không bị bóp trong thanh dưới.
    val wide = screenW >= 600 || (bigFont && screenW >= 480)
    val holder = rememberSaveableStateHolder()
    // Radar giữ WebView sống sau lần mở đầu tiên (không tải lại bản đồ khi đổi tab).
    var radarOpened by rememberSaveable { mutableStateOf(false) }
    if (tab == Tab.RADAR) radarOpened = true

    LaunchedEffect(msg) {
        msg?.let {
            snack.showSnackbar(it)
            vm.clearMessage()
        }
    }
    BackHandler(enabled = tab != Tab.TODAY) { tabId = 0 }

    fun select(t: Tab) {
        if (s.haptics && t != tab) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        tabId = t.id
    }

    data class Dest(val tab: Tab, val label: String, val off: ImageVector, val on: ImageVector)
    val dests = listOf(
        Dest(Tab.TODAY, l.t("Hôm nay", "Today"), Icons.Outlined.WbSunny, Icons.Rounded.WbSunny),
        Dest(Tab.FORECAST, l.t("Dự báo", "Forecast"), Icons.Outlined.Schedule, Icons.Rounded.Schedule),
        Dest(Tab.RADAR, l.t("Radar", "Radar"), Icons.Outlined.Map, Icons.Rounded.Map),
        Dest(Tab.PLACES, l.t("Địa điểm", "Places"), Icons.Outlined.Place, Icons.Rounded.Place),
        Dest(Tab.SETTINGS, l.t("Cài đặt", "Settings"), Icons.Outlined.Settings, Icons.Rounded.Settings)
    )

    Box(Modifier.fillMaxSize()) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            if (!wide) {
                NavigationBar {
                    dests.forEach { d ->
                        NavigationBarItem(
                            selected = tab == d.tab,
                            onClick = { select(d.tab) },
                            icon = { Icon(if (tab == d.tab) d.on else d.off, contentDescription = d.label) },
                            label = { Text(d.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            alwaysShowLabel = !bigFont
                        )
                    }
                }
            }
        }
    ) { pad ->
        Row(Modifier.padding(pad).fillMaxSize()) {
            if (wide) {
                NavigationRail {
                    dests.forEach { d ->
                        NavigationRailItem(
                            selected = tab == d.tab,
                            onClick = { select(d.tab) },
                            icon = { Icon(if (tab == d.tab) d.on else d.off, contentDescription = d.label) },
                            label = { Text(d.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            alwaysShowLabel = !bigFont
                        )
                    }
                }
            }
            Box(Modifier.weight(1f).fillMaxSize()) {
                // Đổi tab: chỉ fade-through ngắn (bỏ scale cả màn hình); trạng thái cuộn của từng tab được giữ lại.
                AnimatedContent(
                    targetState = tab,
                    transitionSpec = {
                        if (motion == "off") EnterTransition.None togetherWith ExitTransition.None
                        else fadeIn(tween(180, delayMillis = 60)) togetherWith fadeOut(tween(90))
                    },
                    label = "tabs"
                ) { t ->
                    holder.SaveableStateProvider(t.id) {
                        when (t) {
                            Tab.TODAY -> TodayScreen(vm)
                            Tab.FORECAST -> ForecastScreen(vm)
                            Tab.RADAR -> Unit
                            Tab.PLACES -> PlacesScreen(vm)
                            Tab.SETTINGS -> SettingsScreen(vm)
                        }
                    }
                }
                if (radarOpened) {
                    val radarActive = tab == Tab.RADAR
                    Box(
                        Modifier.layout { measurable, constraints ->
                            if (radarActive) {
                                val p = measurable.measure(constraints)
                                layout(p.width, p.height) { p.placeRelative(0, 0) }
                            } else {
                                val p = measurable.measure(constraints)
                                layout(0, 0) { }
                            }
                        }
                    ) { RadarScreen(vm, radarActive) }
                }
            }
        }
    }
    if (s.fpsOverlay) FpsOverlay()
    }
}
