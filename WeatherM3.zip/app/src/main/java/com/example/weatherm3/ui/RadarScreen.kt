@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.weatherm3.ui

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.weatherm3.core.LocalL
import com.example.weatherm3.ui.theme.AppWavyProgress
import com.example.weatherm3.ui.theme.isDarkFor
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private class RadarBridge(val onFrames: (Int) -> Unit, val onFrame: (Int, Long) -> Unit) {
    private val h = Handler(Looper.getMainLooper())
    @JavascriptInterface fun frames(n: Int) { h.post { onFrames(n) } }
    @JavascriptInterface fun frame(i: Int, ts: Double) { h.post { onFrame(i, ts.toLong()) } }
}

private fun radarHtml(lat: Double, lon: Double, dark: Boolean): String {
    val base = if (dark) "dark_all" else "light_all"
    return """
<!DOCTYPE html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css"/>
<style>html,body,#map{height:100%;margin:0;background:${if (dark) "#111" else "#eee"}}.leaflet-control-attribution{font-size:9px}</style>
</head><body><div id="map"></div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
<script>
var map=L.map('map',{zoomControl:false}).setView([$lat,$lon],6);
function baseUrl(d){return 'https://{s}.basemaps.cartocdn.com/'+(d?'dark_all':'light_all')+'/{z}/{x}/{y}{r}.png';}
var baseLayer=L.tileLayer(baseUrl($dark),{maxZoom:12,subdomains:'abcd',updateWhenIdle:true,keepBuffer:1,
 attribution:'&copy; OpenStreetMap &copy; CARTO | Radar: RainViewer'}).addTo(map);
var marker=L.circleMarker([$lat,$lon],{radius:6,color:'#fff',weight:2,fillColor:'#e53935',fillOpacity:1}).addTo(map);
var host='',frames=[],radarLayer=null,cur=0,timer=null,playing=false;
function urlFor(i){return host+frames[i].path+'/256/{z}/{x}/{y}/2/1_1.png';}
// Chỉ MỘT lớp radar: đổi frame bằng setUrl (trước đây tạo ~13 lớp tile cùng tải ở độ mờ 0).
function show(i){ if(!frames.length)return; cur=(i+frames.length)%frames.length;
 if(!radarLayer){radarLayer=L.tileLayer(urlFor(cur),{opacity:0.75,maxNativeZoom:7,maxZoom:12,tileSize:256,updateWhenIdle:true,keepBuffer:1}).addTo(map);}
 else{radarLayer.setUrl(urlFor(cur));}
 if(window.Android)Android.frame(cur,frames[cur].time); }
function setFrame(i){ stop(); show(i); }
function play(){ if(playing)return; playing=true; timer=setInterval(function(){show(cur+1);},800); }
function stop(){ playing=false; if(timer){clearInterval(timer);timer=null;} }
function setPlace(la,lo){ map.setView([la,lo],map.getZoom()); marker.setLatLng([la,lo]); }
function setDark(d){ baseLayer.setUrl(baseUrl(d)); document.body.style.background=d?'#111':'#eee'; }
document.addEventListener('visibilitychange',function(){ if(document.hidden)stop(); });
fetch('https://api.rainviewer.com/public/weather-maps.json').then(function(r){return r.json();}).then(function(d){
 host=d.host; frames=(d.radar&&d.radar.past)?d.radar.past:[];
 if(window.Android)Android.frames(frames.length);
 show(frames.length-1);
}).catch(function(e){ if(window.Android)Android.frames(0); });
</script></body></html>
""".trimIndent()
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun RadarScreen(vm: AppViewModel, active: Boolean = true) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val l = LocalL.current
    val place = s.activePlace()
    val dark = isDarkFor(s, isSystemInDarkTheme())
    var frames by remember { mutableIntStateOf(0) }
    var index by remember { mutableIntStateOf(0) }
    var ts by remember { mutableStateOf(0L) }
    var playing by remember { mutableStateOf(false) }
    var web by remember { mutableStateOf<WebView?>(null) }
    var pageReady by remember { mutableStateOf(false) }
    val initial = remember { Triple(place.lat, place.lon, dark) }
    var applied by remember { mutableStateOf(initial) }

    // Tạm dừng khi tab radar không hiển thị: dừng phát, dừng WebView; tiếp tục khi quay lại.
    LaunchedEffect(active, web) {
        val w = web ?: return@LaunchedEffect
        if (active) w.onResume() else {
            playing = false
            w.evaluateJavascript("stop()", null)
            w.onPause()
        }
    }
    // Đổi địa điểm / theme: gọi JS thay vì tạo lại WebView (không tải lại bản đồ từ mạng).
    LaunchedEffect(place.lat, place.lon, dark, pageReady) {
        val w = web ?: return@LaunchedEffect
        if (!pageReady) return@LaunchedEffect
        val cur = Triple(place.lat, place.lon, dark)
        if (cur.first != applied.first || cur.second != applied.second) w.evaluateJavascript("setPlace(${cur.first},${cur.second})", null)
        if (cur.third != applied.third) w.evaluateJavascript("setDark(${cur.third})", null)
        applied = cur
    }
    val fmt = remember(s.hour24, l.lang) {
        DateTimeFormatter.ofPattern(if (s.hour24) "HH:mm" else "h:mm a", l.locale).withZone(ZoneId.systemDefault())
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(l.t("Radar mưa", "Rain radar")) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f).fillMaxWidth().clip(MaterialTheme.shapes.extraLarge)) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            addJavascriptInterface(
                                RadarBridge({ n -> frames = n }, { i, t -> index = i; ts = t }),
                                "Android"
                            )
                            webViewClient = object : WebViewClient() {
                                override fun onPageFinished(view: WebView?, url: String?) { pageReady = true }
                            }
                            loadDataWithBaseURL("https://appassets.local/", radarHtml(initial.first, initial.second, initial.third), "text/html", "utf-8", null)
                            web = this
                        }
                    },
                    onRelease = { it.destroy(); web = null; pageReady = false },
                    update = { }
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                FilledIconButton(onClick = {
                    playing = !playing
                    web?.evaluateJavascript(if (playing) "play()" else "stop()", null)
                }) {
                    Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, l.t("Phát / dừng", "Play / pause"))
                }
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text(
                        if (frames == 0) l.t("Đang tải radar…", "Loading radar…")
                        else if (ts > 0) fmt.format(Instant.ofEpochSecond(ts)) else "",
                        style = MaterialTheme.typography.titleMedium
                    )
                    if (frames > 1 && active) {
                        AppWavyProgress(index.toFloat() / (frames - 1), Modifier.fillMaxWidth())
                    }
                }
            }
            if (frames > 1) {
                Slider(
                    value = index.toFloat(),
                    onValueChange = {
                        playing = false
                        index = it.toInt()
                        web?.evaluateJavascript("setFrame(${it.toInt()})", null)
                    },
                    valueRange = 0f..(frames - 1).toFloat(),
                    steps = (frames - 2).coerceAtLeast(0)
                )
            }
            Text(
                l.t("Dữ liệu radar: RainViewer · Bản đồ: OpenStreetMap, CARTO", "Radar: RainViewer · Map: OpenStreetMap, CARTO"),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
    }
}
