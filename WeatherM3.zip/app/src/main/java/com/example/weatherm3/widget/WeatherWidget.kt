package com.example.weatherm3.widget

import android.content.Context
import android.content.Intent
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.LocalContext
import androidx.glance.LocalSize
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import com.example.weatherm3.MainActivity
import com.example.weatherm3.core.Fmt
import com.example.weatherm3.core.L
import com.example.weatherm3.core.describe
import com.example.weatherm3.core.resolveLang
import com.example.weatherm3.core.skyOf
import com.example.weatherm3.data.AppSettings
import com.example.weatherm3.data.Repo
import com.example.weatherm3.data.SettingsRepository
import com.example.weatherm3.data.WeatherBundle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class WeatherWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Responsive(
        setOf(DpSize(110.dp, 110.dp), DpSize(250.dp, 110.dp), DpSize(250.dp, 250.dp))
    )

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val s = SettingsRepository(context).current()
        val b = withContext(Dispatchers.IO) { Repo.cached(context, s.activePlace(), s) }
        val l = L(resolveLang(s.language))
        provideContent {
            GlanceTheme {
                WidgetBody(s, b, l)
            }
        }
    }
}

class WeatherWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = WeatherWidget()
}

private fun symbol(code: Int, isDay: Boolean): String = when (skyOf(code)) {
    com.example.weatherm3.core.Sky.CLEAR -> if (isDay) "☀" else "☾"
    com.example.weatherm3.core.Sky.PARTLY -> "⛅"
    com.example.weatherm3.core.Sky.CLOUDY -> "☁"
    com.example.weatherm3.core.Sky.FOG -> "🌫"
    com.example.weatherm3.core.Sky.DRIZZLE, com.example.weatherm3.core.Sky.RAIN -> "🌧"
    com.example.weatherm3.core.Sky.SNOW -> "❄"
    com.example.weatherm3.core.Sky.STORM -> "⛈"
}

@Composable
private fun WidgetBody(s: AppSettings, b: WeatherBundle?, l: L) {
    val size = LocalSize.current
    val ctx = LocalContext.current
    val root = GlanceModifier
        .fillMaxSize()
        .background(GlanceTheme.colors.widgetBackground)
        .cornerRadius(24.dp)
        .padding(14.dp)
        .clickable(actionStartActivity(Intent(ctx, MainActivity::class.java)))

    if (b == null) {
        Column(root, verticalAlignment = Alignment.CenterVertically, horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                l.t("Mở app để tải dữ liệu", "Open the app to load data"),
                style = TextStyle(color = GlanceTheme.colors.onSurface, fontSize = 14.sp)
            )
        }
        return
    }

    val c = b.current
    Column(root, verticalAlignment = Alignment.CenterVertically) {
        Row(modifier = GlanceModifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                symbol(c.code, c.isDay),
                style = TextStyle(color = GlanceTheme.colors.primary, fontSize = 34.sp)
            )
            Spacer(GlanceModifier.width(10.dp))
            Column {
                Text(
                    Fmt.temp(c.tempC, s),
                    style = TextStyle(color = GlanceTheme.colors.onSurface, fontSize = 36.sp, fontWeight = FontWeight.Medium)
                )
                Text(
                    s.activePlace().name,
                    style = TextStyle(color = GlanceTheme.colors.onSurfaceVariant, fontSize = 12.sp)
                )
            }
        }
        Spacer(GlanceModifier.height(4.dp))
        Text(
            describe(c.code, l) + " · " + l.t("Cảm giác ", "Feels ") + Fmt.temp(c.feelsC, s),
            style = TextStyle(color = GlanceTheme.colors.onSurface, fontSize = 13.sp)
        )
        if (size.width >= 250.dp) {
            Spacer(GlanceModifier.height(8.dp))
            Row(modifier = GlanceModifier.fillMaxWidth()) {
                b.hourly.take(5).forEach { h ->
                    Column(
                        modifier = GlanceModifier.padding(end = 14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(Fmt.hourLabel(h.time, s, l), style = TextStyle(color = GlanceTheme.colors.onSurfaceVariant, fontSize = 11.sp))
                        Text(symbol(h.code, h.isDay), style = TextStyle(color = GlanceTheme.colors.primary, fontSize = 18.sp))
                        Text(Fmt.temp(h.tempC, s), style = TextStyle(color = GlanceTheme.colors.onSurface, fontSize = 13.sp))
                    }
                }
            }
        }
        if (size.height >= 250.dp) {
            Spacer(GlanceModifier.height(10.dp))
            b.daily.take(4).forEachIndexed { i, d ->
                Row(modifier = GlanceModifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(Fmt.dayName(d.date, i, l), style = TextStyle(color = GlanceTheme.colors.onSurface, fontSize = 13.sp), modifier = GlanceModifier.width(64.dp))
                    Text(symbol(d.code, true), style = TextStyle(color = GlanceTheme.colors.primary, fontSize = 15.sp), modifier = GlanceModifier.width(30.dp))
                    Text(Fmt.temp(d.minC, s) + " / " + Fmt.temp(d.maxC, s), style = TextStyle(color = GlanceTheme.colors.onSurfaceVariant, fontSize = 13.sp))
                }
            }
        }
    }
}
