package com.example.weatherm3.core

import com.example.weatherm3.data.AppSettings
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.roundToInt

object Fmt {
    private val formatters = ConcurrentHashMap<String, DateTimeFormatter>()
    private fun fmt(pattern: String, l: L): DateTimeFormatter =
        formatters.getOrPut(pattern + "|" + l.lang) { DateTimeFormatter.ofPattern(pattern, l.locale) }
    private fun two(n: Int) = if (n < 10) "0$n" else n.toString()

    fun tempVal(c: Double, s: AppSettings): Double = if (s.tempUnit == "f") c * 9.0 / 5.0 + 32.0 else c
    fun temp(c: Double, s: AppSettings): String = "${tempVal(c, s).roundToInt()}°"
    fun tempFull(c: Double, s: AppSettings): String = temp(c, s) + (if (s.tempUnit == "f") "F" else "C")

    fun beaufort(kmh: Double): Int {
        val ms = kmh / 3.6
        val limits = doubleArrayOf(0.3, 1.6, 3.4, 5.5, 8.0, 10.8, 13.9, 17.2, 20.8, 24.5, 28.5, 32.7)
        var b = 0
        for (x in limits) if (ms >= x) b++
        return b
    }

    fun wind(kmh: Double, s: AppSettings): String = when (s.windUnit) {
        "ms" -> "%.1f m/s".format(kmh / 3.6)
        "mph" -> "${(kmh * 0.621371).roundToInt()} mph"
        "kn" -> "${(kmh * 0.539957).roundToInt()} kn"
        "bft" -> "Bft ${beaufort(kmh)}"
        else -> "${kmh.roundToInt()} km/h"
    }

    fun pressure(hpa: Double, s: AppSettings): String = when (s.pressureUnit) {
        "mmhg" -> "${(hpa * 0.750062).roundToInt()} mmHg"
        "inhg" -> "%.2f inHg".format(hpa * 0.02953)
        else -> "${hpa.roundToInt()} hPa"
    }

    fun rain(mm: Double, s: AppSettings): String =
        if (s.rainUnit == "in") "%.2f in".format(mm * 0.0393701) else "%.1f mm".format(mm)

    fun vis(km: Double, s: AppSettings): String =
        if (s.visUnit == "mi") "%.1f mi".format(km * 0.621371) else "%.1f km".format(km)

    private fun pattern(s: AppSettings) = if (s.hour24) "HH:mm" else "h:mm a"

    /** local = "yyyy-MM-ddTHH:mm" */
    fun clock(local: String?, s: AppSettings, l: L): String {
        if (local == null) return "--:--"
        return runCatching {
            LocalDateTime.parse(local).format(fmt(pattern(s), l))
        }.getOrDefault("--:--")
    }

    fun hourLabel(local: String, s: AppSettings, l: L): String {
        val p = if (s.hour24) "HH" else "h a"
        return runCatching { LocalDateTime.parse(local).format(fmt(p, l)) }
            .getOrDefault(local.takeLast(5))
    }

    fun dayName(date: String, index: Int, l: L): String {
        if (index == 0) return l.t("Hôm nay", "Today")
        return runCatching {
            LocalDate.parse(date).dayOfWeek.getDisplayName(TextStyle.SHORT, l.locale)
        }.getOrDefault(date.takeLast(5))
    }

    fun dayShort(date: String): String = runCatching {
        val d = LocalDate.parse(date)
        two(d.dayOfMonth) + "/" + two(d.monthValue)
    }.getOrDefault(date.takeLast(5))

    fun dateTimeLong(local: String, s: AppSettings, l: L): String = runCatching {
        val dt = LocalDateTime.parse(local)
        val dn = dt.dayOfWeek.getDisplayName(TextStyle.SHORT, l.locale)
        dn + " " + two(dt.dayOfMonth) + "/" + two(dt.monthValue) + " · " + dt.format(fmt(pattern(s), l))
    }.getOrDefault(local)
}
