package com.example.weatherm3.data

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

// ---------- Open-Meteo: dự báo ----------
@Serializable
data class OmCurrent(
    val time: String = "",
    @SerialName("temperature_2m") val temp: Double = 0.0,
    @SerialName("relative_humidity_2m") val humidity: Double = 0.0,
    @SerialName("apparent_temperature") val feels: Double = 0.0,
    @SerialName("is_day") val isDay: Double = 1.0,
    @SerialName("weather_code") val code: Double = 0.0,
    @SerialName("wind_speed_10m") val wind: Double = 0.0,
    @SerialName("wind_direction_10m") val windDir: Double = 0.0,
    @SerialName("pressure_msl") val pressure: Double = 1013.0,
    @SerialName("cloud_cover") val cloud: Double = 0.0
)

@Serializable
data class OmHourly(
    val time: List<String> = emptyList(),
    @SerialName("temperature_2m") val temp: List<Double?> = emptyList(),
    @SerialName("precipitation_probability") val rain: List<Double?> = emptyList(),
    @SerialName("weather_code") val code: List<Double?> = emptyList(),
    @SerialName("is_day") val isDay: List<Double?> = emptyList(),
    @SerialName("uv_index") val uv: List<Double?> = emptyList(),
    val visibility: List<Double?> = emptyList(),
    @SerialName("wind_speed_10m") val wind: List<Double?> = emptyList()
)

@Serializable
data class OmDaily(
    val time: List<String> = emptyList(),
    @SerialName("weather_code") val code: List<Double?> = emptyList(),
    @SerialName("temperature_2m_max") val max: List<Double?> = emptyList(),
    @SerialName("temperature_2m_min") val min: List<Double?> = emptyList(),
    val sunrise: List<String?> = emptyList(),
    val sunset: List<String?> = emptyList(),
    @SerialName("uv_index_max") val uv: List<Double?> = emptyList(),
    @SerialName("precipitation_probability_max") val rain: List<Double?> = emptyList(),
    @SerialName("precipitation_sum") val rainSum: List<Double?> = emptyList()
)

@Serializable
data class OmResponse(
    val current: OmCurrent = OmCurrent(),
    val hourly: OmHourly = OmHourly(),
    val daily: OmDaily = OmDaily(),
    val timezone: String = "auto"
)

// ---------- Open-Meteo: chất lượng không khí ----------
@Serializable
data class AqCurrent(
    @SerialName("us_aqi") val usAqi: Double? = null,
    @SerialName("pm2_5") val pm25: Double? = null,
    val pm10: Double? = null,
    val ozone: Double? = null,
    @SerialName("nitrogen_dioxide") val no2: Double? = null
)

@Serializable
data class AqResponse(val current: AqCurrent? = null)

// ---------- Open-Meteo: tìm thành phố ----------
@Serializable
data class GeoResult(
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val country: String = "",
    val admin1: String? = null
)

@Serializable
data class GeoResponse(val results: List<GeoResult> = emptyList())

interface OpenMeteoApi {
    @GET("v1/forecast")
    suspend fun forecast(
        @Query("latitude") lat: Double,
        @Query("longitude") lon: Double,
        @Query("current") current: String = "temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,wind_speed_10m,wind_direction_10m,pressure_msl,cloud_cover",
        @Query("hourly") hourly: String = "temperature_2m,precipitation_probability,weather_code,is_day,uv_index,visibility,wind_speed_10m",
        @Query("daily") daily: String = "weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_probability_max,precipitation_sum",
        @Query("timezone") timezone: String = "auto",
        @Query("forecast_days") days: Int = 10
    ): OmResponse
}

interface AirApi {
    @GET("v1/air-quality")
    suspend fun air(
        @Query("latitude") lat: Double,
        @Query("longitude") lon: Double,
        @Query("current") current: String = "us_aqi,pm10,pm2_5,ozone,nitrogen_dioxide",
        @Query("timezone") timezone: String = "auto"
    ): AqResponse
}

interface GeoApi {
    @GET("v1/search")
    suspend fun search(
        @Query("name") name: String,
        @Query("count") count: Int = 8,
        @Query("language") language: String = "vi",
        @Query("format") format: String = "json"
    ): GeoResponse
}

object Net {
    val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        coerceInputValues = true
    }

    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .addInterceptor { chain ->
                chain.proceed(chain.request().newBuilder().header("User-Agent", "WeatherM3/2.0").build())
            }
            .build()
    }

    private fun <T> build(base: String, c: Class<T>): T =
        Retrofit.Builder()
            .baseUrl(base)
            .client(client)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(c)

    val forecast: OpenMeteoApi by lazy { build("https://api.open-meteo.com/", OpenMeteoApi::class.java) }
    val air: AirApi by lazy { build("https://air-quality-api.open-meteo.com/", AirApi::class.java) }
    val geo: GeoApi by lazy { build("https://geocoding-api.open-meteo.com/", GeoApi::class.java) }
}
