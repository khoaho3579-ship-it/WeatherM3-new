@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.weatherm3.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import com.example.weatherm3.ui.components.AdaptiveChoice
import com.example.weatherm3.ui.components.rememberTextWidthDp
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.weatherm3.core.Fmt
import com.example.weatherm3.core.LocalL
import com.example.weatherm3.core.describe
import com.example.weatherm3.core.skyOf
import com.example.weatherm3.data.AppSettings
import com.example.weatherm3.data.HourW
import com.example.weatherm3.ui.components.Card28
import com.example.weatherm3.ui.components.WeatherGlyph
import com.example.weatherm3.ui.components.AppLoadingCenter

@Composable
fun ForecastScreen(vm: AppViewModel) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val ui by vm.ui.collectAsStateWithLifecycle()
    val l = LocalL.current
    var mode by rememberSaveable { mutableIntStateOf(0) }
    val scroll = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
    val bg = MaterialTheme.colorScheme.background

    Scaffold(
        modifier = Modifier.nestedScroll(scroll.nestedScrollConnection),
        containerColor = bg,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            LargeTopAppBar(
                title = { Text(l.t("Dự báo", "Forecast")) },
                scrollBehavior = scroll,
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = bg,
                    scrolledContainerColor = MaterialTheme.colorScheme.surfaceContainer
                )
            )
        }
    ) { pad ->
        val b = ui.bundle
        val hours24 = remember(b) { b?.hourly?.take(24) ?: emptyList() }
        val hours48 = remember(b) { b?.hourly?.take(48) ?: emptyList() }
        val tempMin = rememberTextWidthDp(if (s.tempUnit == "f") "-188°" else "-88°", MaterialTheme.typography.titleMedium)
        val rainMin = rememberTextWidthDp("100%", MaterialTheme.typography.labelLarge)
        if (b == null) {
            AppLoadingCenter(Modifier.padding(pad).fillMaxSize())
        } else {
            LazyColumn(
                Modifier.padding(pad).fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item(key = "mode", contentType = "mode") {
                    AdaptiveChoice(
                        listOf("0" to l.t("Theo giờ", "Hourly"), "1" to l.t("Theo ngày", "Daily")),
                        mode.toString(),
                        onSelect = { mode = it.toInt() }
                    )
                }
                if (mode == 0) {
                    item(key = "chart", contentType = "chart") { TempChart(hours24, s) }
                    items(hours48, key = { it.time }, contentType = { "hourRow" }) { h ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(MaterialTheme.shapes.large)
                                .background(MaterialTheme.colorScheme.surfaceContainer)
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(Fmt.dateTimeLong(h.time, s, l), Modifier.weight(1f).padding(end = 8.dp), style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            WeatherGlyph(skyOf(h.code), h.isDay, false, Modifier.size(30.dp))
                            Text(Fmt.temp(h.tempC, s), Modifier.widthIn(min = tempMin).padding(start = 8.dp), style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.End, maxLines = 1, softWrap = false)
                            Text("${h.rainChance}%", Modifier.widthIn(min = rainMin).padding(start = 8.dp), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge, textAlign = TextAlign.End, maxLines = 1, softWrap = false)
                        }
                    }
                } else {
                    items(b.daily.size, key = { b.daily[it].date }, contentType = { "dayRow" }) { i ->
                        val d = b.daily[i]
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(MaterialTheme.shapes.large)
                                .background(MaterialTheme.colorScheme.surfaceContainer)
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            WeatherGlyph(skyOf(d.code), true, false, Modifier.size(40.dp))
                            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                Text(Fmt.dayName(d.date, i, l) + " · " + Fmt.dayShort(d.date), style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(describe(d.code, l), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(
                                    l.t("Mưa ", "Rain ") + (d.rainChance?.let { "$it%" } ?: "--") +
                                        (d.rainMm?.let { " · " + Fmt.rain(it, s) } ?: "") +
                                        " · ☀ " + Fmt.clock(d.sunrise, s, l) + " – " + Fmt.clock(d.sunset, s, l),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 3,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Column(Modifier.padding(start = 8.dp).widthIn(min = tempMin), horizontalAlignment = Alignment.End) {
                                Text(Fmt.temp(d.maxC, s), style = MaterialTheme.typography.titleMedium, maxLines = 1, softWrap = false)
                                Text(Fmt.temp(d.minC, s), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, softWrap = false)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TempChart(hours: List<HourW>, s: AppSettings) {
    if (hours.size < 2) return
    val line = MaterialTheme.colorScheme.primary
    val fill = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
    val min = hours.minOf { it.tempC }
    val max = hours.maxOf { it.tempC }
    val span = (max - min).coerceAtLeast(1.0)
    Card28(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth()) {
                Text(Fmt.temp(max, s), Modifier.weight(1f), style = MaterialTheme.typography.labelLarge)
                Text(Fmt.temp(min, s), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Canvas(Modifier.fillMaxWidth().height(120.dp).padding(vertical = 8.dp)) {
                val stepX = size.width / (hours.size - 1)
                fun y(t: Double) = (size.height - ((t - min) / span).toFloat() * size.height)
                val path = Path()
                val area = Path()
                hours.forEachIndexed { i, h ->
                    val x = stepX * i
                    if (i == 0) { path.moveTo(x, y(h.tempC)); area.moveTo(x, size.height); area.lineTo(x, y(h.tempC)) }
                    else { path.lineTo(x, y(h.tempC)); area.lineTo(x, y(h.tempC)) }
                }
                area.lineTo(size.width, size.height)
                area.close()
                drawPath(area, fill)
                drawPath(path, line, style = Stroke(5f, cap = StrokeCap.Round))
                drawCircle(line, 8f, Offset(0f, y(hours.first().tempC)))
            }
        }
    }
}
