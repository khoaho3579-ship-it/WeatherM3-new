# CHANGELOG

## 3.0.0 (versionCode 3) — bản sửa lỗi chữ tràn + hiệu năng

> **Chưa build, chưa chạy thử.** Môi trường tạo bản này không có Android SDK/Gradle/mạng, nên code chỉ được
> kiểm tra tĩnh (cân ngoặc, đối chiếu import/API bằng mắt). Hãy chạy GitHub Actions và gửi lại log nếu có lỗi biên dịch.

### Chữ tràn / lệch icon
- `Theme.kt`: bỏ nhân `fontScale` vào `fontSize/lineHeight` (lỗi T1). Cỡ chữ app nay đi qua `LocalDensity.fontScale`
  = hệ thống × app, có **giới hạn tổng** (Tắt/130/150/200%) và dòng hiển thị "tổng hiệu dụng" trong Cài đặt.
- `Theme.kt`: độ đậm chặn 300–700 (T2); mọi `TextStyle` có `LineHeightStyle(Center, Trim.None)` (T12).
- Mới `ui/components/Adaptive.kt`: `AdaptiveChoice` (Segmented ↔ chip tự chuyển khi đo thấy không vừa), `ActionRow` (FlowRow),
  `AppTonalButton/AppOutlinedButton` (≥48dp, tối đa 2 dòng), `IconText` (icon căn dòng đầu), `FitText` (tự co), `rememberTextWidthDp`.
- `TodayScreen.kt`: `DailyCard` bỏ cột 62/44/34dp → `widthIn(min = đo theo chuỗi mẫu)`, tự chuyển bố cục 2 dòng khi chữ lớn
  hoặc bề rộng < 340dp (T3); `MetricBox` dùng `IconText`, la bàn gió xuống dưới khi hẹp/chữ lớn (T5); `HeaderCard` dùng `FitText`
  thay `96.sp` cố định, tên địa điểm `maxLines=2` (T6); banner offline/cảnh báo/gợi ý dùng `IconText`.
- `ForecastScreen.kt`: bỏ cột 52/44dp, chuỗi dài có `maxLines`/`Ellipsis` (T4); Segmented → `AdaptiveChoice`.
- `WeatherApp.kt`: nhãn điều hướng `maxLines=1`+`Ellipsis`; chữ lớn → chỉ hiện nhãn mục chọn, và dùng Rail khi màn ≥ 480dp (T7).
- `SettingsScreen.kt`: `Segmented` → `AdaptiveChoice` (T8); các hàng nút → `ActionRow` (T9); tiêu đề nhóm `weight(1f)`+`maxLines=2` (T10);
  ô chọn màu 40→48dp; xem trước phông có "-12°F" và "Ầ Ễ Ữ Ậ Ợ".
- `PlacesScreen.kt`: tên/ghi chú địa điểm có `maxLines`+`Ellipsis`.

### Hiệu năng
- P1: thêm `buildTypes.release` (R8 + shrinkResources), `proguard-rules.pro` đầy đủ, `profileinstaller`, workflow build **release + debug**.
- Ký APK: `signingConfigs.shared` (khóa thử nghiệm cố định `app/weatherm3-test.jks`, hoặc secret) cho cả debug/release → cài đè được.
- P2/P4: `remember` cho `seedColorScheme`/`dynamic*`/typography/shapes; 35 `animateColorAsState` → **1** `Animatable` (320ms, chỉ chạy khi đổi màu).
- P3: `L` thành `@Immutable data class`, `LocalL` = `staticCompositionLocalOf`, `L(...)` được `remember`.
- P5: `Appear` chỉ animate một lần/phần tử/phiên; chỉ 6 phần tử đầu có stagger.
- P6: đổi tab chỉ fade-through 180ms (bỏ `scaleIn`); `SaveableStateHolder` giữ vị trí cuộn; **WebView radar được giữ sống** và tạm dừng khi ẩn.
- P7: radar chỉ **1 lớp** tile (`setUrl` theo frame), `updateWhenIdle`, `keepBuffer:1`, dừng khi ẩn; đổi địa điểm/theme bằng JS, không tạo lại WebView.
- P8: tái dùng `Path` (`rewind`), vòng tải 180→72 điểm, sóng bước 3→6px.
- P9 (một phần): hoạt ảnh header chỉ chạy khi RESUMED và header còn nhìn thấy.
- P10: `Insights`, `take()`, nhóm hàng được `remember`; mọi `items` có `key`/`contentType`.
- P11: cache `DateTimeFormatter` theo (pattern, locale); bỏ `String.format` ở đường nóng.
- P12: `@Immutable` cho model và `AppSettings`.
- P14 (một phần): thêm **Lớp phủ FPS** (Cài đặt → Dành cho nhà phát triển) và "Chế độ thử tràn chữ" (ép ×2.0).

### Lỗi tự phát hiện thêm
- `README.md` ghi BOM 2026.09.00 nhưng `libs.versions.toml` dùng 2025.10.01 → README đã sửa theo toml.
- Banner offline (`TodayScreen`) là `Row` có `Text` không `weight` → có thể đẩy chữ ra ngoài; đã sửa bằng `IconText`.
- Dự án không có Gradle wrapper (workflow dùng `gradle` 8.13 cài sẵn) — giữ nguyên, ghi chú trong README.
- P12 bị đánh giá hơi quá: Kotlin 2.x bật strong skipping mặc định nên model "không ổn định" vẫn skip được theo `equals`; `@Immutable` vẫn có ích.

### CHƯA làm (xem PERFORMANCE.md mục cuối)
Phông nhúng (Roboto Flex/Be Vietnam Pro… cần file .ttf, không có mạng), module Baseline Profile, UI model/ViewModel dựng sẵn chuỗi,
`WindowSizeClass`, `@Preview` ma trận, đồng hồ hoạt ảnh dùng chung/giới hạn 30 FPS cho backdrop, Predictive Back có bo góc,
dùng thành phần Expressive chính thức, toàn bộ mục 5 (cá nhân hóa mở rộng), mục 6 (thiết kế lại), mục 6B (bộ chuyển động) và mục 7 (tính năng mới).
